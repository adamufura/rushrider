<?php

    $hashed__password = password_hash('root', PASSWORD_DEFAULT, array());


    echo $hashed__password;