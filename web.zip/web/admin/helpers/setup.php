<?php

$host = "localhost";
$connect_username = "root";
$connection_password = "";
$db = "rushrider";

$connection = mysqli_connect($host, $connect_username, $connection_password, $db);