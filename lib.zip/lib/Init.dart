class Init {
  static String urlInit = "http://rushriders.atwebpages.com/server/";

  // static String urlInit = "https://192.168.1.214/rushrider/server/";

  // static String urlInit = "https://10.178.209.232/complaintsystemapp/backend/users/student.php";
}
